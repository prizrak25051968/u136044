<?
$MESS ['MODULE_GENDALF_NAME'] = 'atlanta';
$MESS ['MODULE_GENDALF_URI'] = 'http://internet.atlanta.ru';
$MESS ['MODULE_GENDALF_CONSULTING_NAME'] = 'Company website';
$MESS ['MODULE_GENDALF_CONSULTING_DESCRIPTION'] = 'Company website wizard';
