<span style="text-align:center">"�������"</span>
<br>
<br>
<img width="96" src="<?echo SITE_TEMPLATE_PATH?>/images/logo.png" height="102"><br>