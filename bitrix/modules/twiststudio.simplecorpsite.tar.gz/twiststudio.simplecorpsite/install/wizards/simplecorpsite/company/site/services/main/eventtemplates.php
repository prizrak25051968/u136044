<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)
	die();

if (!defined("WIZARD_SITE_ID"))
	return;

if (!defined("WIZARD_SITE_DIR"))
	return;

	$bitrixTemplateDir = $_SERVER["DOCUMENT_ROOT"].BX_PERSONAL_ROOT."/templates/".WIZARD_TEMPLATE_ID."_".WIZARD_THEME_ID;
 
if (WIZARD_INSTALL_DEMO_DATA)
{
	$emess = new CEventMessage;
	$id1 = $emess->Add(array(
	    "ACTIVE"=>'Y',
	    "EVENT_NAME"=>"FEEDBACK_FORM",
	    "LID" => WIZARD_SITE_ID,
	    "EMAIL_FROM" => "#EMAIL_TO#",
	    "EMAIL_TO" => "#DEFAULT_EMAIL_FROM#",
	    "SUBJECT" => "#SITE_NAME#: ".GetMessage("TWISTSTUDIO_SIMPLECORPSITE_SOOBSENIE_SO_STRANIC"),
	    "BODY_TYPE"=>"text",
	    "MESSAGE" => "
	    ".GetMessage("TWISTSTUDIO_SIMPLECORPSITE_INFORMACIONNOE_SOOBS")
	));
	$emess = new CEventMessage;
	$id2 =  $emess->Add(array(
	    "ACTIVE"=>'Y',
	    "EVENT_NAME"=>"FEEDBACK_FORM",
	    "LID" => WIZARD_SITE_ID,
	    "EMAIL_FROM" => "#EMAIL_TO#",
	    "EMAIL_TO" => "#DEFAULT_EMAIL_FROM#",
	    "SUBJECT" => "#SITE_NAME#: ".GetMessage("TWISTSTUDIO_SIMPLECORPSITE_SOOBSENIE_SO_STRANIC1"),
	    "BODY_TYPE"=>"text",
	    "MESSAGE" => "
	    ".GetMessage("TWISTSTUDIO_SIMPLECORPSITE_INFORMACIONNOE_SOOBS1")
	));
}

CWizardUtil::ReplaceMacros(WIZARD_SITE_PATH."/portfolio/reviews/index.php", array("FEEDBACK_REVIEWS" => $id1));
CWizardUtil::ReplaceMacros($bitrixTemplateDir."/components/bitrix/catalog/service/element.php", array("FEEDBACK_SERVICE" => $id2));
?>