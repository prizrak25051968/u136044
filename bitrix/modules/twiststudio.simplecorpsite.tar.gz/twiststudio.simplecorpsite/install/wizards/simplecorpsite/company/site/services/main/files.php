<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)
	die();

if (!defined("WIZARD_SITE_ID"))
	return;

if (!defined("WIZARD_SITE_DIR"))
	return;
 
$bitrixTemplateDir = BX_PERSONAL_ROOT."/templates/".WIZARD_TEMPLATE_ID."_".WIZARD_THEME_ID; 
	
	
if (WIZARD_INSTALL_DEMO_DATA)
{
	$path = str_replace("//", "/", WIZARD_ABSOLUTE_PATH."/site/public/".LANGUAGE_ID."/"); 
	
	$handle = @opendir($path);
	if ($handle)
	{
		while ($file = readdir($handle))
		{
			if (in_array($file, array(".", "..")))
				continue; 

			CopyDirFiles(
				$path.$file,
				WIZARD_SITE_PATH."/".$file,
				$rewrite = true, 
				$recursive = true,
				$delete_after_copy = false
			);
		}
	}
	//throw new Exception(WIZARD_SITE_PATH.'=='.WIZARD_SITE_DIR);

	WizardServices::ReplaceMacrosRecursive(WIZARD_SITE_PATH, Array("SITE_DIR" => WIZARD_SITE_DIR));

	$arUrlRewrite = array(); 
	if (file_exists($_SERVER['DOCUMENT_ROOT']."/urlrewrite.php"))
	{
		include($_SERVER['DOCUMENT_ROOT']."/urlrewrite.php");
	}

	$sd = WIZARD_SITE_DIR;
	$arNewUrlRewrite = array(
		array(
			"CONDITION"	=>	"#^{$sd}about/events/#",
			"RULE"	=>	"",
			"ID"	=>	"bitrix:news",
			"PATH"	=>	"{$sd}about/events/index.php",
		),
		array(
			"CONDITION"	=>	"#^{$sd}about/news/#",
			"RULE"	=>	"",
			"ID"	=>	"bitrix:news",
			"PATH"	=>	"{$sd}about/news/index.php",
		),
		array(
			"CONDITION"	=>	"#^{$sd}article/#",
			"RULE"	=>	"",
			"ID"	=>	"bitrix:news",
			"PATH"	=>	"{$sd}article/index.php",
		),
		array(
			"CONDITION"	=>	"#^{$sd}service/#",
			"RULE"	=>	"",
			"ID"	=>	"bitrix:catalog",
			"PATH"	=>	"{$sd}service/index.php",
		),
	); 
	
	foreach ($arNewUrlRewrite as $arUrl)
	{
		if (!in_array($arUrl, $arUrlRewrite))
		{
			CUrlRewriter::Add($arUrl);
		}
	}
}

function ___writeToAreasFile($fn, $text)
{
	if(file_exists($fn) && !is_writable($abs_path) && defined("BX_FILE_PERMISSIONS"))
		@chmod($abs_path, BX_FILE_PERMISSIONS);

	$fd = @fopen($fn, "wb");
	if(!$fd)
		return false;

	if(false === fwrite($fd, $text))
	{
		fclose($fd);
		return false;
	}

	fclose($fd);

	if(defined("BX_FILE_PERMISSIONS"))
		@chmod($fn, BX_FILE_PERMISSIONS);
}

CheckDirPath(WIZARD_SITE_PATH."include_areas/");

$wizard =& $this->GetWizard();

$header_conacts = '';
$phone = $wizard->GetVar("siteHeaderPhone");
if ($phone)
$header_conacts .= <<<TTT
<div><img src="{$bitrixTemplateDir}/images/header_phone.png"/><span id="header_phone">{$phone}</span></div>

TTT;
$email = $wizard->GetVar("siteHeaderEmail");
if ($email)
$header_conacts .= <<<TTT
<div><img src="{$bitrixTemplateDir}/images/header_mail.png"/><span id="header_mail"><a href="mailto:$email">{$email}</a></span></div>

TTT;
$skype = $wizard->GetVar("siteHeaderSkype");
if ($skype)
$header_conacts .= <<<TTT
<div><img src="{$bitrixTemplateDir}/images/header_skype.png"/><span id="header_skype"><a href="skype:{$skype}?call">{$skype}</a></span></div>

TTT;

$footer_contacts = $mailtag = '';
if ($email) {
$email = $wizard->GetVar("siteFooterEmail");
$footer_contacts .= <<<TTT
<div><img src="{$bitrixTemplateDir}/images/footer_mail.png"/><span id="footer_mail"><a href="mailto:{$email}">{$email}</a></span></div>
TTT;
$mailtag = <<<TTT
<a href="mailto:{$email}"><img border="0" src="{$bitrixTemplateDir}/images/mail_icon.gif"></a>
TTT;
}
if ($skype)
$skype = $wizard->GetVar("siteFooterSkype");
$footer_contacts .= <<<TTT
<div><img src="{$bitrixTemplateDir}/images/footer_skype.png"/><span id="footer_skype"><a href="skype:{$skype}?call">{$skype}</a></span></div>

TTT;


___writeToAreasFile(WIZARD_SITE_PATH."include_areas/name.php", $wizard->GetVar("siteCompany"));
___writeToAreasFile(WIZARD_SITE_PATH."include_areas/header_contacts.php", $header_conacts);
___writeToAreasFile(WIZARD_SITE_PATH."include_areas/header_mail.php", $mailtag);
___writeToAreasFile(WIZARD_SITE_PATH."include_areas/footer_contacts.php", $footer_contacts);
___writeToAreasFile(WIZARD_SITE_PATH."include_areas/phonefooter.php", $wizard->GetVar("siteFooterPhone"));
___writeToAreasFile(WIZARD_SITE_PATH."include_areas/contacts.php", $wizard->GetVar("siteContacts"));
___writeToAreasFile(WIZARD_SITE_PATH."include_areas/address.php", $wizard->GetVar("siteAddress"));
___writeToAreasFile(WIZARD_SITE_PATH."include_areas/slogan.php", $wizard->GetVar("siteSlogan"));
___writeToAreasFile(WIZARD_SITE_PATH."include_areas/copyright.php", $wizard->GetVar("siteCopyright"));

$siteLogo = $wizard->GetVar("siteLogo");
if($siteLogo>0)
{
	$ff = CFile::GetByID($siteLogo);
	if($zr = $ff->Fetch())
	{
		$strOldFile = str_replace("//", "/", WIZARD_SITE_ROOT_PATH."/".(COption::GetOptionString("main", "upload_dir", "upload"))."/".$zr["SUBDIR"]."/".$zr["FILE_NAME"]);
		//@copy($strOldFile, WIZARD_SITE_PATH."include_areas/logo.gif");
		___writeToAreasFile(WIZARD_SITE_PATH."include_areas/logo.php", '<img src="'.$bitrixTemplateDir.'/images/logo.png"  />');
		//CFile::Delete($siteLogo);
	}
}
elseif(!file_exists(WIZARD_SITE_PATH."include_areas/logo.php"))
{
	//copy(WIZARD_THEME_ABSOLUTE_PATH."/lang/".LANGUAGE_ID."/logo.gif", WIZARD_SITE_PATH."include_areas/logo.gif");
	___writeToAreasFile(WIZARD_SITE_PATH."include_areas/logo.php", '<img src="'.$bitrixTemplateDir.'/images/logo.png"  />');
}


?>