<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<div class="news-list">
<script type="text/javascript">

			function show(state){

					document.getElementById('window').style.display = state;						
					document.getElementById('wrap').style.display = state; 			
			}

		</script>
<?foreach($arResult["ITEMS"] as $arItem):?>
<div class="feedback_item">
	<?
	$this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_EDIT"));
	$this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BNL_ELEMENT_DELETE_CONFIRM')));
	?>
	<div class="feed_back_item" id="<?=$this->GetEditAreaId($arItem['ID']);?>">
		<h4 class='feedback_name'><?if($arParams["DISPLAY_NAME"]!="N" && $arItem["NAME"]):?>
				<b><?echo $arItem["NAME"]?></b><br />
		<?endif;?>
</h4>
<ul class="feedback_fields">	<?foreach($arItem["DISPLAY_PROPERTIES"] as $pid=>$arProperty):?>
			<li>
			<?if(is_array($arProperty["DISPLAY_VALUE"])):?>
				<?=implode("&nbsp;/&nbsp;", $arProperty["DISPLAY_VALUE"]);?>
			<?else:?>
				<?=$arProperty["DISPLAY_VALUE"];?>
			<?endif?>
			</li><br />
		<?endforeach;?>
	</ul>
	</div>
		<div onclick="show('none')" id="wrap"></div>
				<button class="openbutton" onclick="show('block')">�������� ������</button>
				</div>
<?endforeach;?>

<div style='cleaar:both'></div>

</div>
