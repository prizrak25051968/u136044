
<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
IncludeTemplateLangFile(__FILE__);
?></div></td></tr>
<tr><td><?$APPLICATION->IncludeComponent("bitrix:main.include", ".default", array(
	"AREA_FILE_SHOW" => "sect",
	"AREA_FILE_SUFFIX" => "feedback",
	"AREA_FILE_RECURSIVE" => "Y",
	"EDIT_TEMPLATE" => ""
	),
	false
);?><br>
</p></td></tr>
<tr style='display: block;
margin: 30px 0 0 0;
left: 0;
box-shadow: #000 0px 0px 15px;'>
<td class='footer_div'>
<div class="comp">
<?$APPLICATION->IncludeComponent("bitrix:main.include", ".default", array(
	"AREA_FILE_SHOW" => "sect",
	"AREA_FILE_SUFFIX" => "komp",
	"AREA_FILE_RECURSIVE" => "Y",
	"EDIT_TEMPLATE" => ""
	),
	false
);?></div>
<div class='footercontent'>
<?$APPLICATION->IncludeComponent("bitrix:main.include", ".default", array(
	"AREA_FILE_SHOW" => "sect",
	"AREA_FILE_SUFFIX" => "content",
	"AREA_FILE_RECURSIVE" => "Y",
	"EDIT_TEMPLATE" => ""
	),
	false
);?>
</div>
<div class='created'>
<?$APPLICATION->IncludeComponent("bitrix:main.include", ".default", array(
	"AREA_FILE_SHOW" => "sect",
	"AREA_FILE_SUFFIX" => "Created",
	"AREA_FILE_RECURSIVE" => "Y",
	"EDIT_TEMPLATE" => ""
	),
	false
);?>
</div>
</td></tr>
</table>
			<div id="window">
						
				<img class="close" onclick="show('none')" src="<?=SITE_TEMPLATE_PATH?>\images\close.png">

				<form method="post" id="feedback-form">
				<p>����������, �������� ���� ���������� ������, ���� ����������� �������� � ����.</p>
				<p><input type='text' class='input_field' name='Name' value placeholder="���� ���"></p>
				<p><input type='text' class='input_field' name='phone'value placeholder="��� ����� ��������"></p>
				<input type='text' name='obj'  value='<?echo $arItem["NAME"]?>' style='display:none;'>
				<input type="submit" class='submit' value="��������">
				</form>
				</div>
</body>		
</html>
<?$APPLICATION->SetAdditionalCSS(SITE_TEMPLATE_PATH."/blog.css");
$APPLICATION->SetAdditionalCSS(SITE_TEMPLATE_PATH."/common.css");?>