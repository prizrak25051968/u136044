<?
$MESS["MAIN_FEEDBACK_COMPONENT_DESCR"] = "Ein E-Mail-Formular wird erstellt.";
$MESS["MAIN_FEEDBACK_COMPONENT_NAME"] = "R�ckmeldungsformular";
?>