<?
$MESS["TMPL_POPULAR_POSTS"] = "Popular Posts";
$MESS["TMPL_NEW_COMMENTS"] = "New Comments";
$MESS["TMPL_TAGS_CLOUD"] = "Tag Cloud";
$MESS["TMPL_FEEDBACK"] = "Feedback";
$MESS["TMPL_AUTH"] = "Authorize";
$MESS["TMPL_UP"] = "Up";
$MESS["TMPL_RSS"] = "RSS subscribe";
?>