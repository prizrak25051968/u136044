<h1><?$APPLICATION->IncludeFile( 
        SITE_DIR."include_areas/name.php", 
        Array(), 
        Array("MODE"=>"php") 
       ); ?>
</h1>