<?
$MESS["SITE_TEMPLATE_NAME"] = "Text Only";
$MESS["SITE_TEMPLATE_DESCRIPTION"] = "An ascetic, text-only fixed width template.<br />This is a contemporary template that renders without using any image files. Any desired modification is ultimately simple: just change the colors.";
?>