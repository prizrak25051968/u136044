<?
$MESS["MF_REQ_NAME"] = "Bitte geben Sie Ihren Namen ein.";
$MESS["MF_REQ_EMAIL"] = "Bitte geben Sie die Kontakt-E-Mail an.";
$MESS["MF_OK_MESSAGE"] = "Vielen Dank! Ihre Nachricht wurde bearbeitet.";
$MESS["MF_CAPTHCA_EMPTY"] = "CAPTCHA-Code ist erforderlich.";
$MESS["MF_CAPTCHA_WRONG"] = "Der eingegebene CAPTCHA-Code ist falsch.";
$MESS["MF_EMAIL_NOT_VALID"] = "Die angegebene E-Mail-Adresse ist ung�ltig.";
$MESS["MF_REQ_MESSAGE"] = "Der Nachrichtentext ist erforderlich.";
$MESS["MF_SESS_EXP"] = "Ihre Sitzung ist abgelaufen. Bitte senden Sie Ihre Nachricht erneut.";
?>