<?
DEFINE('WIZ_PATH','/bitrix/wizards/gendalf/consulting/');


require_once($_SERVER['DOCUMENT_ROOT']."/bitrix/modules/main/install/wizard_sol/wizard.php");

class SelectSiteStep extends CSelectSiteWizardStep
{
	function InitStep()
	{
		$wizard =& $this->GetWizard();
		$wizard->solutionName = "consulting";
		parent::InitStep();
	}
}


class SelectTemplateStep extends CSelectTemplateWizardStep
{
}

class SelectThemeStep extends CSelectThemeWizardStep
{

}

class SiteSettingsStep extends CSiteSettingsWizardStep
{
	function InitStep()
	{
		$wizard =& $this->GetWizard();
		$wizard->solutionName = "consulting";
		parent::InitStep();

		$templateID = $wizard->GetVar("templateID");
		$themeID = $wizard->GetVar($templateID."_themeID");
		$bitrixTemplateDir = BX_PERSONAL_ROOT."/templates/".WIZARD_TEMPLATE_ID."_".WIZARD_THEME_ID; 
		
		$siteLogo = $this->GetFileContentImgSrc(WIZARD_SITE_PATH."include_areas/logo.php", $bitrixTemplateDir."/images/logo.png");
		$vars = Array(
			"siteLogo" 			=> $siteLogo,
			"siteCompany" 		=> $this->GetFileContent(WIZARD_TEMPLATE_ABSOLUTE_PATH."include_areas/name.php", GetMessage("WIZ_COMPANY_NAME_DEF")),
			"siteAddress" 		=> $this->GetFileContent(WIZARD_TEMPLATE_ABSOLUTE_PATH."include_areas/address.php", GetMessage("WIZ_ADDRESS_DEF")),
			"siteSlogan" 		=> $this->GetFileContent(WIZARD_TEMPLATE_ABSOLUTE_PATH."include_areas/slogan.php", GetMessage("WIZ_SLOGAN_DEF")),
			"siteCopyright" 	=> $this->GetFileContent(WIZARD_TEMPLATE_ABSOLUTE_PATH."include_areas/copyright.php", GetMessage("WIZ_COPYRIGHT_DEF")),
			"siteFooterPhone" 	=> $this->GetFileContent(WIZARD_TEMPLATE_ABSOLUTE_PATH."include_areas/phonefooter.php", GetMessage("WIZ_FOOTER_PHONE_DEF")),
		);
		if ($headerarea = file_get_contents(WIZARD_SITE_PATH."include_areas/header_contacts.php")) {
			if (preg_match('~id="header_phone">(.*?)</span>~',$headerarea,$m)) $vars['siteHeaderPhone'] = $m[1];
			else ($vars['siteHeaderPhone'] = GetMessage("WIZ_HEADER_PHONE_DEF"));
			if (preg_match('~id="header_mail"><a.*?>(.*?)</a></span>~',$headerarea,$m)) $vars['siteHeaderEmail'] = $m[1];
			else ($vars['siteHeaderEmail'] = GetMessage("WIZ_HEADER_EMAIL_DEF"));
			if (preg_match('~id="header_skype"><a.*?>(.*?)</a></span>~',$headerarea,$m)) $vars['siteHeaderSkype'] = $m[1];
			else ($vars['siteHeaderSkype'] = GetMessage("WIZ_HEADER_SKYPE_DEF"));
		} else {
			$vars['siteHeaderPhone'] = GetMessage("WIZ_HEADER_PHONE_DEF");
			$vars['siteHeaderEmail'] = GetMessage("WIZ_HEADER_EMAIL_DEF");
			$vars['siteHeaderSkype'] = GetMessage("WIZ_HEADER_SKYPE_DEF");
		}
		if ($footerarea = file_get_contents(WIZARD_SITE_PATH."include_areas/footer_contacts.php")) {
			if (preg_match('~id="footer_mail"><a.*?>(.*?)</a></span>~',$footerarea,$m)) $vars['siteFooterEmail'] = $m[1];
			else ($vars['siteFooterEmail'] = GetMessage("WIZ_FOOTER_EMAIL_DEF"));
			if (preg_match('~id="footer_skype"><a.*?>(.*?)</a></span>~',$footerarea,$m)) $vars['siteFooterSkype'] = $m[1];
			else ($vars['siteFooterSkype'] = GetMessage("WIZ_FOOTER_SKYPE_DEF"));
		} else {
			$vars['siteFooterEmail'] = GetMessage("WIZ_FOOTER_EMAIL_DEF");
			$vars['siteFooterSkype'] = GetMessage("WIZ_FOOTER_SKYPE_DEF");
		}
		
		$tel = $this->GetFileContent(WIZARD_SITE_PATH."include_areas/header_contacts.php", GetMessage("WIZ_COMPANY_HEADER_PHONE_DEF"));  
		$wizard->SetDefaultVars($vars);
	}


	function ShowStep()
	{
		
		$wizard =& $this->GetWizard();
		$templateID = $wizard->GetVar("templateID");
		$themeID = $wizard->GetVar($templateID."_themeID");
		$siteLogo = $wizard->GetVar("siteLogo", true);
		$message = array(
			'WIZ_COMPANY_LOGO'=>GetMessage('WIZ_COMPANY_LOGO'),
		
			'WIZ_COMPANY_NAME'=>GetMessage('WIZ_COMPANY_NAME'),
			'WIZ_COMPANY_NAME_DEF'=>GetMessage('WIZ_COMPANY_NAME_DEF'),
		
			'WIZ_SLOGAN'=>GetMessage('WIZ_SLOGAN'),
			'WIZ_SLOGAN_DEF'=>GetMessage('WIZ_SLOGAN_DEF'),
		
			'WIZ_ADDRESS'=>GetMessage('WIZ_ADDRESS'),
			'WIZ_ADDRESS_DEF'=>GetMessage('WIZ_ADDRESS_DEF'),

			'WIZ_COPYRIGHT'=>GetMessage('WIZ_COPYRIGHT'),
			'WIZ_COPYRIGHT_DEF'=>GetMessage('WIZ_COPYRIGHT_DEF'),

		
			'WIZ_HEADER_PHONE'=>GetMessage('WIZ_HEADER_PHONE'),
			'WIZ_HEADER_PHONE_DEF'=>GetMessage('WIZ_HEADER_PHONE_DEF'),
		
			'WIZ_HEADER_EMAIL'=>GetMessage('WIZ_HEADER_EMAIL'),
			'WIZ_HEADER_EMAIL_DEF'=>GetMessage('WIZ_HEADER_EMAIL_DEF'),
		
			'WIZ_HEADER_SKYPE'=>GetMessage('WIZ_HEADER_SKYPE'),
			'WIZ_HEADER_SKYPE_DEF'=>GetMessage('WIZ_HEADER_SKYPE_DEF'),

		
			'WIZ_FOOTER_PHONE'=>GetMessage('WIZ_FOOTER_PHONE'),
			'WIZ_FOOTER_PHONE_DEF'=>GetMessage('WIZ_FOOTER_PHONE_DEF'),
		
			'WIZ_FOOTER_EMAIL'=>GetMessage('WIZ_FOOTER_EMAIL'),
			'WIZ_FOOTER_EMAIL_DEF'=>GetMessage('WIZ_FOOTER_EMAIL_DEF'),
		
			'WIZ_FOOTER_SKYPE'=>GetMessage('WIZ_FOOTER_SKYPE'),
			'WIZ_FOOTER_SKYPE_DEF'=>GetMessage('WIZ_FOOTER_SKYPE_DEF'),
		
			'wiz_structure_data'=>GetMessage('wiz_structure_data'),
		);
		$path = WIZ_PATH.'images/'.LANGUAGE_ID.'/lense';
		$this->content = <<<GENDALF
		
<script>
	wimg = {};
	wimg['siteLogo'] = new Image();
	wimg['siteLogo'].src='$path/siteLogo.jpg';
	wimg['siteCompany'] = new Image();
	wimg['siteCompany'].src='$path/siteCompany.jpg';
	wimg['siteSlogan'] = new Image();
	wimg['siteSlogan'].src='$path/siteSlogan.jpg';
	wimg['siteCopyright'] = new Image();
	wimg['siteCopyright'].src='$path/siteCopyright.jpg';
	wimg['siteAddress'] = new Image();
	wimg['siteAddress'].src='$path/siteAddress.jpg';
	
	wimg['siteHeaderPhone'] = new Image();
	wimg['siteHeaderPhone'].src='$path/siteHeaderPhone.jpg';

	wimg['siteFooterPhone'] = new Image();
	wimg['siteFooterPhone'].src='$path/siteFooterPhone.jpg';
	wimg['siteFooterEmail'] = new Image();
	wimg['siteFooterEmail'].src='$path/siteFooterEmail.jpg';
	
	window.lensecanchange = true;
	function chimg(v) {
		if (window.lensecanchange) document.getElementById('wiz_cons_img').src=wimg[v].src;
	}
	function fiximg(v) {
		chimg(v);
		window.lensecanchange = false;
	}
	function freeimg(v) {
		window.lensecanchange = true;
	}
	</script>
<table width="100%">
<tr>
<td colspan="2">
	<img id="wiz_cons_img" src="$path/clear.jpg"/>
</td>
</tr>
<tr onmouseover="chimg('siteLogo')">
<td>
	<label id="siteLogo">{$message['WIZ_COMPANY_LOGO']}</label>
</td><td>
	{$this->ShowFileField("siteLogo", Array("show_file_info" => "N", "id" => "siteCompany"))}
</td></tr>

<tr onmouseover="chimg('siteCompany')"><td>
	<label id="siteCompany">{$message['WIZ_COMPANY_NAME']}</label>
</td><td>
	{$this->ShowInputField("text", "siteCompany", Array('style'=>'width: 100%;','id'=>'siteCompany',"onfocus"=>"fiximg('siteCompany')",'onblur'=>"freeimg('siteCompany')"))}
</td></tr>

<tr onmouseover="chimg('siteSlogan')"><td>
	<label id="siteSlogan">{$message['WIZ_SLOGAN']}</label>
</td><td>
	{$this->ShowInputField("text", "siteSlogan", Array('style'=>'width: 100%;','id'=>'siteSlogan',"onfocus"=>"fiximg('siteSlogan')","onblur"=>"freeimg('siteSlogan')"))}
</td></tr>

<tr onmouseover="chimg('siteAddress')"><td>
	<label id="siteAddress">{$message['WIZ_ADDRESS']}</label>
</td><td>
	{$this->ShowInputField("text", "siteAddress", Array('style'=>'width: 100%;','id'=>'siteAddress',"onfocus"=>"fiximg('siteAddress')","onblur"=>"freeimg('siteAddress')"))}
</td></tr>

<tr onmouseover="chimg('siteCopyright')"><td>
	<label id="siteCopyright">{$message['WIZ_COPYRIGHT']}</label>
</td><td>
	{$this->ShowInputField("text", "siteCopyright", Array('style'=>'width: 100%;','id'=>'siteCopyright',"onfocus"=>"fiximg('siteCopyright')","onblur"=>"freeimg('siteCopyright')"))}
</td></tr>


<tr onmouseover="chimg('siteHeaderPhone')"><td>
	<label id="siteHeaderPhone">{$message['WIZ_HEADER_PHONE']}</label>
</td><td>
	{$this->ShowInputField("text", "siteHeaderPhone", Array('style'=>'width: 100%;','id'=>'siteHeaderPhone',"onfocus"=>"fiximg('siteHeaderPhone')","onblur"=>"freeimg('siteHeaderPhone')"))}
</td></tr>

<tr onmouseover="chimg('siteHeaderEmail')"><td>
	<label id="siteHeaderEmail">{$message['WIZ_HEADER_EMAIL']}</label>
</td><td>
	{$this->ShowInputField("text", "siteHeaderEmail", Array('style'=>'width: 100%;','id'=>'siteHeaderEmail',"onfocus"=>"fiximg('siteHeaderEmail')","onblur"=>"freeimg('siteHeaderEmail')"))}
</td></tr>

<tr onmouseover="chimg('siteHeaderSkype')"><td>
	<label id="siteHeaderSkype">{$message['WIZ_HEADER_SKYPE']}</label>
</td><td>
	{$this->ShowInputField("text", "siteHeaderSkype", Array('style'=>'width: 100%;','id'=>'siteHeaderSkype',"onfocus"=>"fiximg('siteHeaderSkype')","onblur"=>"freeimg('siteHeaderSkype')"))}
</td></tr>


<tr onmouseover="chimg('siteFooterPhone')"><td>
	<label id="siteFooterPhone">{$message['WIZ_FOOTER_PHONE']}</label>
</td><td>
	{$this->ShowInputField("text", "siteFooterPhone", Array('style'=>'width: 100%;','id'=>'siteFooterPhone',"onfocus"=>"fiximg('siteFooterPhone')","onblur"=>"freeimg('siteFooterPhone')"))}
</td></tr>

<tr onmouseover="chimg('siteFooterEmail')"><td>
	<label id="siteFooterEmail">{$message['WIZ_FOOTER_EMAIL']}</label>
</td><td>
	{$this->ShowInputField("text", "siteFooterEmail", Array('style'=>'width: 100%;','id'=>'siteFooterEmail',"onfocus"=>"fiximg('siteFooterEmail')","onblur"=>"freeimg('siteFooterEmail')"))}
</td></tr>

<tr onmouseover="chimg('siteFooterSkype')"><td>
	<label id="siteFooterSkype">{$message['WIZ_FOOTER_SKYPE']}</label>
</td><td>
	{$this->ShowInputField("text", "siteFooterSkype", Array('style'=>'width: 100%;','id'=>'siteFooterSkype',"onfocus"=>"fiximg('siteFooterSkype')","onblur"=>"freeimg('siteFooterSkype')"))}
</td></tr>

</table>


<div style="margin-top: 10px;">
	{$this->ShowCheckboxField("installDemoData", "Y",(array("id" => "install-demo-data") + ($_SERVER["PHP_SELF"] == "/index.php" && empty($siteLogo) ? array() : array("checked" => false))))}
	<label for="install-demo-data">{$message["wiz_structure_data"]}</label>
</div>

GENDALF;

		$formName = $wizard->GetFormName();
		$installCaption = $this->GetNextCaption();
		$nextCaption = GetMessage("NEXT_BUTTON");
	}

	function OnPostForm()
	{
		$wizard =& $this->GetWizard();
		$res = $this->SaveFile("siteLogo", Array("extensions" => "gif,jpg,jpeg,png", "max_height" => 140, "max_width" => 150, "make_preview" => "Y"));
		COption::SetOptionString("main", "wizard_site_logo", $res, "", $wizard->GetVar("siteID")); 
	}
}

class DataInstallStep extends CDataInstallWizardStep
{
	function CorrectServices(&$arServices)
	{
		$wizard =& $this->GetWizard();
		if($wizard->GetVar("installDemoData") != "Y")
		{
		}
	}
}

class FinishStep extends CFinishWizardStep
{
}
?>