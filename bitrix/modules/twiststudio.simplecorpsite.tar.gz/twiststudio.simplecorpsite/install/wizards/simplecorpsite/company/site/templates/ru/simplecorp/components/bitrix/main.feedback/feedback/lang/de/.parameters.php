<?
$MESS["MFP_ALL_REQ"] = "(alle nicht erforderliche)";
$MESS["MFP_EMAIL_TO"] = "Empf�nger-E-Mail-Adresse";
$MESS["MFP_EMAIL_TEMPLATES"] = "E-Mail-Vorlagen";
$MESS["MFP_MESSAGE"] = "Nachricht";
$MESS["MFP_NAME"] = "Name";
$MESS["MFP_REQUIRED_FIELDS"] = "Pflichtfelder";
$MESS["MFP_OK_MESSAGE"] = "Text, der nach dem Versand angezeigt wird.";
$MESS["MFP_OK_TEXT"] = "Vielen Dank! Ihre Nachricht wurde bearbeitet.";
$MESS["MFP_CAPTCHA"] = "CAPTCHA f�r nicht angemeldete Besucher verwenden";
?>