<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<html>
<head>

<link rel="shortcut icon" type="image/x-icon" href="<?=SITE_TEMPLATE_PATH?>/favicon.ico" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<?$APPLICATION->ShowMeta("robots")?>
<?$APPLICATION->ShowMeta("keywords")?>
<?$APPLICATION->ShowMeta("description")?>
<title><?$APPLICATION->ShowTitle()?></title>
<?$APPLICATION->ShowHead();?>
<?IncludeTemplateLangFile(__FILE__);?>
<link rel="stylesheet" type="text/css" href="<?=SITE_TEMPLATE_PATH?>/colors.css" />
<link rel="stylesheet" type="text/css" href="<?=SITE_TEMPLATE_PATH?>/print.css" media="print" />
<script src="<?=SITE_TEMPLATE_PATH?>/scripts/jquery.js"></script>
<script src="<?=SITE_TEMPLATE_PATH?>/scripts/mobilyslider.js"></script>
<script src="<?=SITE_TEMPLATE_PATH?>/scripts/init.js"></script>
<script>document.getElementById('feedback-form').onsubmit = function(){
  var http = new XMLHttpRequest();
  http.open("POST", "contacts.php", true);
  http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  http.send("nameFF=" + this.nameFF.value + "&contactFF=" + this.contactFF.value + "&messageFF=" + this.messageFF.value);
  http.onreadystatechange = function() {
    if (http.readyState == 4 && http.status == 200) {
      alert(http.responseText + ', ���� ��������� ��������.\n���� ����������� ������� ��� � ������� 2-� ����.\n���������� �� ������� � ����� �����!');
    }
  }
  http.onerror = function() {
    alert('��������, ������ �� ���� ��������');
  }
  return false;
}</script>
</head>
<body>	

<div id="panel"><?$APPLICATION->ShowPanel();?></div>
<table style='width:1000px; margin:0 auto;border-collapse: collapse;'>
<tr style='box-shadow: #000 0px 0px 15px;'><td id='header'>
<div class="header_motto">
<?$APPLICATION->IncludeComponent("bitrix:main.include", ".default", array(
	"AREA_FILE_SHOW" => "sect",
	"AREA_FILE_SUFFIX" => "headmotto",
	"AREA_FILE_RECURSIVE" => "Y",
	"EDIT_TEMPLATE" => ""
	),
	false
);?>
</div>
<div class="header_feedback">
<?$APPLICATION->IncludeComponent("bitrix:main.include", ".default", array(
	"AREA_FILE_SHOW" => "sect",
	"AREA_FILE_SUFFIX" => "headfeed",
	"AREA_FILE_RECURSIVE" => "Y",
	"EDIT_TEMPLATE" => "standard.php"
	),
	false
);?>
</div>
</td></tr>
<tr style='box-shadow: #000 0px 0px 15px;'><td>
					<?$APPLICATION->IncludeComponent("bitrix:menu", "top_horizontal", array(
	"ROOT_MENU_TYPE" => "top",
	"MENU_CACHE_TYPE" => "N",
	"MENU_CACHE_TIME" => "3600",
	"MENU_CACHE_USE_GROUPS" => "Y",
	"MENU_CACHE_GET_VARS" => array(
	),
	"MAX_LEVEL" => "2",
	"CHILD_MENU_TYPE" => "top_2lvl",
	"USE_EXT" => "Y",
	"DELAY" => "N",
	"ALLOW_MULTI_SELECT" => "Y"
	),
	false
);?></td></tr>
<tr><td><div class='slider'>
<?$APPLICATION->IncludeComponent("bitrix:main.include", ".default", array(
	"AREA_FILE_SHOW" => "sect",
	"AREA_FILE_SUFFIX" => "slider",
	"AREA_FILE_RECURSIVE" => "Y",
	"EDIT_TEMPLATE" => "standard.php"
	),
	false
);?>
</div></td></tr>
					<tr style='background: #fff;
display: block;
margin: 30px 0 0 0;
border-radius: 10px;
border: #C2C2C2 1px solid;'><td style='padding: 0;'>
<div class='content'>
